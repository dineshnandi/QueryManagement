package com.cg.traineemgt.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.traineemgt.dao.IQueryMasterDao;
import com.cg.traineemgt.dto.QueryMaster;




@Service
@Transactional
public class QueryMasterServiceImpl implements IQueryMasterService {

	
	@Autowired
	IQueryMasterDao dao;
	@Override
	public int updateSolution(QueryMaster query) {
		return dao.updateSolution(query);
		

	}
	@Override
	public QueryMaster fetch(int qid) {
		
		return dao.fetch(qid);
	}

}
