package com.cg.traineemgt.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="query_master")
public class QueryMaster {
	
	@Id
	@Column(name="query_id")
	private int qid;
	
	@Column(name="technology")
	private String technology;
	
	@Column(name="query_raised_by")
	private String queryRaisedBy;
	
	@Column(name="query")
	private String query;
	
	@Column(name="solutions")
	private String solutions;
	
	@Column(name="solution_given_by")
	private String solutionGivenBy;

	public int getQid() {
		return qid;
	}

	public void setQid(int qid) {
		this.qid = qid;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getQueryRaisedBy() {
		return queryRaisedBy;
	}

	public void setQueryRaisedBy(String queryRaisedBy) {
		this.queryRaisedBy = queryRaisedBy;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getSolutions() {
		return solutions;
	}

	public void setSolutions(String solutions) {
		this.solutions = solutions;
	}

	public String getSolutionGivenBy() {
		return solutionGivenBy;
	}

	public void setSolutionGivenBy(String solutionGivenBy) {
		this.solutionGivenBy = solutionGivenBy;
	}
	
	
	

}
